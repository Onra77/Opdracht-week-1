User story
W5-001
Als lezer wil ik wil ik kunnen zoeken naar een bepaald artikel door het invoeren van 1 of meerdere trefwoorden zodat ik een artikel over een bepaald ontwerp snel kan vinden.

W5-002
Als blogger wil ik in kunnen loggen zodat ik toegang kan krijgen tot de backend pagina zodat ik bijvoorbeeld artikelen kan schrijven en beheren.
Klaar

W5-003
Als blogger wil ik me kunnen registreren zodat ik mijn gebruikersinformatie op kan slaan en blogs kan plaatsen op de website.
Klaar

W5-004
Als blogger wil ik een bestaand artikel kunnen wijzigen zodat als ik schrijffouten of andere dingen kan verbeteren.
klaar

W5-005
Als blogger wil ik dat alleen mensen die geregistreerd en ingelogd zijn commentaar kunnen geven.
klaar

W5-006
Als geregistreerde en ingelogde gebruiker wil ik mijn gebruikersnaam kunnen verbergen bij het geven van commentaar zodat ik mijn identiteit kan verbergen.
klaar

W5-007
Als blogger wil ik commentaar kunnen verwijderen zodat ik ongewenste berichten kan stoppen.
klaar

W5-008
Als blogger wil ik een openbare profielpagina hebben zodat lezers mijn berichten in kunnen lezen en mijn persoonlijke informatie kunnen bekijken.
klaar

Optionele user stories

Code
User story
W5-009
Als blogger wil ik een text-expander die als ik een artikel aan het schrijven ben door mij zelf gedefinieerde afkortingen die ik type direct omzet in de volledige tekst zodat ik sneller mijn artikelen schrijven
Voorbeeld: Als ik CG type moet er direct CodeGorilla verschijnen. En als ik gn type moet er direct Groningen verschijnen  
Tip: Maak hiervoor gebruik van Javascript


W5-010
Als blogger wil ik dat de wachtwoorden op een veilige manier worden opgeslagen zodat deze bij een datalek niet vrij komen.
Klaar
